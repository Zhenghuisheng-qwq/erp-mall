# 商品配置工作台 V2 演示版

## R01：节点业务配置与路径限制

在模型设计器选中值节点，点击「业务配置」。公共目录跨分类/类型复用；销售定位、物料策略支持仅当前值或当前值及下级；允许值限制支持上级值约束真实下级目标属性。配置不是规格轴。命名入口沿用原命名编辑器；适用配置保持独立。

冲突可保存草稿，但受影响的发布和新建执行会被拒绝，不自动覆盖或求交集。面板可查看已发布配置快照。物料策略目前仅配置、解析和展示，尚未实现多路径共用 MAT 建档。

本轮修复 ProductPlan 创建 SKU 遗漏 COMMON 来源节点的问题。实现、逐项验收和边界见 [R01 验收报告](docs/r01-node-business-configuration.md)。领域检查：`npm run check:r01`；独立 Chrome 闭环：`npm run check:r01:browser`（用 `R01_BROWSER_OUTPUT` 指定独立输出目录）。

独立前端。数据只存在打开它的浏览器里，不连接客户数据库。

## 启动

在项目目录执行：

```bash
npm install
npm run dev
```

终端会打印访问地址。

构建静态文件：

```bash
npm run build
```

构建结果在 `dist`。把这个目录交给任意静态站点服务即可部署，不依赖本机盘符或固定端口。

本地预览构建结果：

```bash
npm run preview
```

## 演示说明

- 数据在浏览器 localStorage，键名 `iyge-v2-mock-db`，当前版本号 15；兼容读取旧版本，不清空历史数据。
- 演示版支持普通 HTTP，各浏览器按站点独立保存本地数据，无需 HTTPS 或 Web Locks。有 Web Locks 时自动使用跨标签页锁；没有时使用本页保存队列，不保证同时跨标签页写入的原子性。实际存储失败仍提示。
- 顶栏可以重置全部、重置当前模块、导出和导入。
- 预设商品都标了「预设演示」，不是线上导出。
- 左侧菜单默认展示全部功能。右上角可切换「管理员 / 运营」。
- 没有真实密码。账号页只校验密码表单，不保存。

## SKU 视图工作台

SKU 管理提供本机视图工作台：筛选先应用、再保存，支持条件组、动态字段、列宽/冻结、多级排序、分组及收藏。操作和验收说明见 [SKU 视图工作台](docs/sku-views-workbench.md)。

## 设备与配件兼容关系

在手机 SKU 行点击「适用配件」，或在配件 SKU 行点击「适用主机」。抽屉区分销售 SKU 和 MAT，显示型号/规格范围、使用条件和声明来源；管理员可在「管理适用关系」中预览、保存声明，或明确选择 MAT 复制独立声明。型号不明确时先配置，系统不会按商品名称猜测。

统一维护入口为「适用关系」，原 MAT 页面及链接继续保留。数据读取异常时先保留原存储并提供备份、校验恢复入口，不自动替换成演示商品。完整规则、验收与限制见 [设备与配件兼容关系工作台](docs/accessory-compatibility-workbench.md)。专项入口：`npm run check:accessory-compatibility`。

## 权益包工作台

从「商品管理 → 权益包」新建，也可在手机 SKU 的「更多 → 组权益包」或适用配件抽屉进入。选设备仅提供适配上下文，显式加入后才交付手机。添加真实 SKU 和独立服务、填写整包报价或留空，保存后按本次包数预览并确认交付清单；历史清单可打印和导出 Excel。

规则、数据安全、实际验证及限制见 [权益包工作台报告](docs/benefit-package-workbench.md)。专项入口：`npm run check:benefit-packages`。当前不进行支付、库存扣减、出库或服务激活。

## 还没接真实后端的部分

分类映射、参数角色、必填、商品族、批量保存事务、规则状态，都在浏览器里计算。

对象怎么连、配置怎么从词表走到规格再走回总览，写在 [docs/商品配置闭环.md](docs/商品配置闭环.md)。

## SPU / SKU 管理

从「商品管理」进入独立的 SPU 管理和 SKU 管理。先保存 SPU，再手工创建或从模板、模型、规划分批追加 SKU；物料继续使用独立的「物料建档」入口。

本轮数据兼容、页面职责、旧链接和验证证据见 [docs/spu-sku-management.md](docs/spu-sku-management.md)。

```bash
npm run typecheck
npm run check:frontend
npm run check:spu-sku
npm run check:integration
npm run build
```

浏览器检查使用独立上下文和项目的 playwright-core，需要已安装 Chrome；可用 `BROWSER_CHANNEL=msedge` 选择 Edge。不会读取或清空日常浏览器数据。

## 导航与商品筛选

顶部按钮统一展开/收起导航；左下“导航设置”保留单栏/双栏偏好。SPU/SKU 列表通过“商品分类”和“更多筛选”即时筛选；“列表设置”集中管理常驻分类栏、列、排序、分组和保存视图。

本轮迁移规则、检查与截图见 [导航与筛选验收报告](docs/frontend-navigation-filter-ux.md)。`npm run check:navigation-filter` 使用独立浏览器上下文及开工源码快照；可用 `NAV_FILTER_BASELINE` 指定基线目录，缺失时会明确失败。

## 历史验收：V2 模型选择器

商品模型设计器允许属性下面再挂属性。新增商品选择器必须按当前节点路径展开，不要把同级属性自动提升到当前页。

品牌下面同时有 Apple（属性值）和型号（属性）时，品牌下拉是「Apple、型号」。选 Apple 就进入 Apple 的子节点；选型号才进入型号节点。不要品牌一行、型号一行同时出现。

这条按现在的 mock 数据验收。以后改成接口数据时再另说，现在不要为接接口去改选择器。锁定范围和完整规则见 [docs/商品配置闭环.md](docs/商品配置闭环.md) 第 5 节。

## 模板兼容配置

商品模型的“配置适用设备”维护整体默认与规格例外；节点快捷入口编辑同一套规则。保存后发布模型，从该发布版本新增销售 SKU 或 MAT 时自动生成各自的适用声明。已有商品在“适用关系”或商品兼容抽屉中“检查模板更新”，先预览再确认，人工修改与取消记录默认受到保护。

实现、全部实际创建入口、数据保护和验收范围见 [模板兼容工作台报告](docs/template-compatibility-workbench.md)。核心检查运行 `npm run check:template-compatibility`，性能运行 `npm run check:template-compatibility:performance`。浏览器使用独立上下文及已安装的 Chrome，可配置 `BROWSER_CHANNEL`；视觉对照运行 `npm run check:template-compatibility:visual`，需要本轮开始前的完整源码快照（`TEMPLATE_COMPATIBILITY_BASELINE`）。缺失环境或基线会明确失败。

兼容关系与权益包的可靠性修复、共享存储保护及新交互见 [本轮实现报告](docs/compatibility-benefit-refinement.md)。专项入口为 `npm run check:compatibility-refinement:domain`、`npm run check:compatibility-refinement:browser` 和 `npm run check:compatibility-refinement:performance`。前后视觉与性能需要实际开工快照，可用 `REFINEMENT_BASELINE` 指定；权益包基线截图使用 `REFINEMENT_BASELINE_ROOT`。浏览器并发中的真实 HTTPS 验证需按报告配置临时测试证书，缺少证书会明确记录该项未验证。
